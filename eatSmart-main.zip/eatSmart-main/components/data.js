export const data = [
    {
      image: "https://cdn.divisupreme.com/storage/2020/10/animation-trigger-methos-click-min.gif",
      
    },
    {
      image: "https://wallpaperaccess.com/full/271965.jpg",
      
    },
    {
      image: "https://image.shutterstock.com/image-photo/full-hd-image-ladybird-on-260nw-1952398060.jpg",
      
    },
    {
      image: "https://cdn.divisupreme.com/storage/2020/10/animation-trigger-methos-click-min.gif",
      
    },
    {
      image: "https://cdn.divisupreme.com/storage/2020/10/change-trigger-method-to-play-animation-on-click.png",
      
    },
    
  ];