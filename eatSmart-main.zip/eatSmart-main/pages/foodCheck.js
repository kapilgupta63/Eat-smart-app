import React from 'react'

export default function FoodCHeck() {
  return (
    <div>FoodXCHeck</div>
  )
}
