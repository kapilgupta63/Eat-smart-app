import React from 'react'

export default function AllergySelect() {
  return (
    <div>AllergyChoose</div>
  )
}
